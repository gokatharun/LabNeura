#include "labneura/eda/netlist.h"

#include "behavioral_synthesis.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <iterator>
#include <optional>
#include <regex>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace labneura::eda {
namespace {

bool is_identifier(const Expression& expression) {
    return expression.get_kind() == ExpressionKind::Identifier;
}

std::optional<bool> literal_value(const Expression& expression) {
    if (expression.get_kind() != ExpressionKind::Literal &&
        expression.get_kind() != ExpressionKind::Opaque) {
        return std::nullopt;
    }
    const auto source = expression.get_source();
    static const std::regex based_literal(
        R"(^\s*[0-9]+\s*'\s*[sS]?[bBoOdDhH]\s*[0-9a-fA-F_xXzZ?]+\s*$)");
    static const std::regex decimal(R"(^\s*([0-9]+)\s*$)");
    std::smatch decimal_match;
    const bool is_based = std::regex_match(source, based_literal);
    const bool is_decimal = std::regex_match(source, decimal_match, decimal);
    if (!is_based && !is_decimal) return std::nullopt;
    if (source.find_first_of("xXzZ?") != std::string::npos) {
        throw std::runtime_error(
            "scalar X/Z constants cannot be mapped to generic tie cells");
    }
    if (is_decimal) {
        return (std::stoull(decimal_match[1].str()) & 1U) != 0;
    }
    const auto apostrophe = source.find('\'');
    const auto base_position = source.find_first_of("bBoOdDhH", apostrophe);
    const auto digit_position = source.find_first_not_of(" \t", base_position + 1);
    const auto digits = source.substr(digit_position);
    const char base = static_cast<char>(
        std::tolower(static_cast<unsigned char>(source[base_position])));
    if (digits.empty()) return std::nullopt;
    if (base == 'd') return (std::stoull(digits) & 1U) != 0;
    const char last_digit = digits.back();
    return (std::isdigit(static_cast<unsigned char>(last_digit))
                ? (last_digit - '0') & 1
                : (std::tolower(static_cast<unsigned char>(last_digit)) - 'a' + 10) &
                      1) != 0;
}

std::string pin_name(std::size_t index) {
    if (index >= 26) {
        throw std::runtime_error(
            "generic Boolean operator has more than 26 operands");
    }
    return std::string(1, static_cast<char>('A' + index));
}

std::string generic_type_for_operator(const std::string& op,
                                      std::size_t operand_count) {
    if (op == "&" || op == "&&") return "AND" + std::to_string(operand_count);
    if (op == "|" || op == "||") return "OR" + std::to_string(operand_count);
    if (op == "^") return "XOR" + std::to_string(operand_count);
    throw std::runtime_error("unsupported Boolean operator in generic mapping: " +
                             op);
}

std::optional<std::string> generic_type_for_primitive(
    const std::string& cell_type, std::size_t input_count) {
    if (cell_type == "pullup" || cell_type == "pulldown") {
        if (input_count != 0) {
            throw std::runtime_error(
                "primitive gate '" + cell_type + "' must not have inputs");
        }
        return cell_type == "pullup" ? "TIEHI" : "TIELO";
    }
    if (cell_type == "buf" || cell_type == "not") {
        if (input_count != 1) {
            throw std::runtime_error(
                "primitive gate '" + cell_type +
                "' must have exactly one input");
        }
        return cell_type == "buf" ? "BUF" : "INV";
    }

    std::string generic_family;
    if (cell_type == "and") generic_family = "AND";
    else if (cell_type == "nand") generic_family = "NAND";
    else if (cell_type == "or") generic_family = "OR";
    else if (cell_type == "nor") generic_family = "NOR";
    else if (cell_type == "xor") generic_family = "XOR";
    else if (cell_type == "xnor") generic_family = "XNOR";
    else return std::nullopt;

    if (input_count < 2) {
        throw std::runtime_error(
            "primitive gate '" + cell_type +
            "' must have at least two inputs");
    }
    return generic_family + std::to_string(input_count);
}

bool is_switch_level_primitive(const std::string& cell_type) {
    return cell_type == "cmos" || cell_type == "nmos" ||
           cell_type == "pmos" || cell_type == "rnmos" ||
           cell_type == "rpmos" || cell_type == "tran" ||
           cell_type == "rtran" || cell_type == "tranif0" ||
           cell_type == "tranif1" || cell_type == "rtranif0" ||
           cell_type == "rtranif1";
}

struct GenericMapper {
    std::vector<Net> nets;
    std::vector<Instance> instances;
    std::unordered_set<std::string> used_names;
    std::size_t next_index = 0;

    explicit GenericMapper(const Module& module) {
        for (const auto& net : module.get_nets()) used_names.insert(net.get_name());
        for (const auto& instance : module.get_instances()) {
            used_names.insert(instance.get_name());
        }
    }

    std::string unique_name(const std::string& prefix) {
        std::string name;
        do {
            name = prefix + std::to_string(next_index++);
        } while (!used_names.insert(name).second);
        return name;
    }

    void add_cell(std::string type, std::vector<PinConnection> connections,
                  const std::string& output) {
        connections.emplace_back("Y", output);
        instances.emplace_back(unique_name("__generic_inst"), std::move(type),
                               std::move(connections));
    }

    void lower_user_defined_primitive(const Instance& instance,
                                      std::vector<Net>& output_nets) {
        if (instance.is_sequential_primitive()) {
            throw std::runtime_error(
                "generic mapping does not support sequential user-defined "
                "primitive '" +
                instance.get_cell_type() + "'");
        }

        const auto& connections = instance.get_connections();
        const auto output_connection = std::find_if(
            connections.begin(), connections.end(),
            [](const PinConnection& connection) {
                return connection.get_pin() == "Y";
            });
        std::vector<std::string> input_nets;
        input_nets.reserve(connections.size());
        for (const auto& connection : connections) {
            if (connection.get_pin() != "Y") {
                input_nets.push_back(connection.get_net());
            }
        }
        if (output_connection == connections.end() || input_nets.empty() ||
            input_nets.size() > 16 || instance.get_primitive_table().empty()) {
            throw std::runtime_error(
                "user-defined primitive '" + instance.get_cell_type() +
                "' has an unsupported port count or empty truth table");
        }

        const std::size_t combinations =
            std::size_t{1} << input_nets.size();
        std::vector<bool> covered(combinations, false);
        std::vector<bool> values(combinations, false);
        std::set<std::string> product_terms;
        for (const auto& row : instance.get_primitive_table()) {
            if (row.inputs.size() != input_nets.size() ||
                (row.output != '0' && row.output != '1')) {
                throw std::runtime_error(
                    "user-defined primitive '" + instance.get_cell_type() +
                    "' uses an unsupported UDP table symbol");
            }
            for (std::size_t combination = 0; combination < combinations;
                 ++combination) {
                bool matches = true;
                for (std::size_t index = 0; index < input_nets.size(); ++index) {
                    const char symbol = static_cast<char>(std::tolower(
                        static_cast<unsigned char>(row.inputs[index])));
                    const bool input =
                        (combination & (std::size_t{1} << index)) != 0;
                    if ((symbol == '0' && input) ||
                        (symbol == '1' && !input)) {
                        matches = false;
                        break;
                    }
                    if (symbol != '0' && symbol != '1' && symbol != '?' &&
                        symbol != 'b') {
                        throw std::runtime_error(
                            "user-defined primitive '" +
                            instance.get_cell_type() +
                            "' uses an unsupported UDP input symbol");
                    }
                }
                if (!matches) continue;
                const bool output = row.output == '1';
                if (covered[combination] && values[combination] != output) {
                    throw std::runtime_error(
                        "user-defined primitive '" +
                        instance.get_cell_type() +
                        "' has conflicting UDP table rows");
                }
                covered[combination] = true;
                values[combination] = output;
            }
            if (row.output == '1') product_terms.insert(row.inputs);
        }
        if (std::find(covered.begin(), covered.end(), false) != covered.end()) {
            throw std::runtime_error(
                "user-defined primitive '" + instance.get_cell_type() +
                "' has unspecified UDP outputs that cannot be mapped");
        }
        const auto output = output_connection->get_net();
        if (std::find(values.begin(), values.end(), false) == values.end()) {
            add_cell("TIEHI", {}, output);
            return;
        }
        if (product_terms.empty()) {
            add_cell("TIELO", {}, output);
            return;
        }

        std::vector<std::string> inverted_inputs(input_nets.size());
        std::vector<std::string> terms;
        terms.reserve(product_terms.size());
        for (const auto& pattern : product_terms) {
            std::vector<std::string> literals;
            for (std::size_t index = 0; index < input_nets.size(); ++index) {
                const auto symbol = static_cast<char>(std::tolower(
                    static_cast<unsigned char>(pattern[index])));
                if (symbol == '?' || symbol == 'b') continue;
                if (symbol == '1') {
                    literals.push_back(input_nets[index]);
                    continue;
                }
                if (inverted_inputs[index].empty()) {
                    inverted_inputs[index] = unique_name("__generic_net");
                    output_nets.emplace_back(inverted_inputs[index],
                                             NetType::Internal);
                    add_cell("INV", {{"A", input_nets[index]}},
                             inverted_inputs[index]);
                }
                literals.push_back(inverted_inputs[index]);
            }

            if (literals.empty()) {
                const auto constant = unique_name("__generic_net");
                output_nets.emplace_back(constant, NetType::Internal);
                add_cell("TIEHI", {}, constant);
                terms.push_back(constant);
            } else if (literals.size() == 1) {
                terms.push_back(literals.front());
            } else {
                const auto term = unique_name("__generic_net");
                output_nets.emplace_back(term, NetType::Internal);
                std::vector<PinConnection> term_inputs;
                for (std::size_t index = 0; index < literals.size(); ++index) {
                    term_inputs.emplace_back(pin_name(index), literals[index]);
                }
                add_cell("AND" + std::to_string(literals.size()),
                         std::move(term_inputs), term);
                terms.push_back(term);
            }
        }

        if (terms.size() == 1) {
            add_cell("BUF", {{"A", terms.front()}}, output);
            return;
        }
        std::vector<PinConnection> sum_inputs;
        for (std::size_t index = 0; index < terms.size(); ++index) {
            sum_inputs.emplace_back(pin_name(index), terms[index]);
        }
        add_cell("OR" + std::to_string(terms.size()), std::move(sum_inputs),
                 output);
    }

    bool collect_associative(const Expression& expression,
                             const std::string& op,
                             std::vector<const Expression*>& operands) {
        if (expression.get_kind() == ExpressionKind::Binary &&
            expression.get_value() == op &&
            expression.get_operands().size() == 2) {
            return collect_associative(expression.get_operands()[0], op,
                                        operands) &&
                   collect_associative(expression.get_operands()[1], op,
                                        operands);
        }
        operands.push_back(&expression);
        return true;
    }

    bool is_supported_operator(const std::string& op) const {
        return op == "&" || op == "&&" || op == "|" || op == "||" ||
               op == "^";
    }

    std::optional<std::string> lower(const Expression& expression,
                                     const std::string& destination) {
        if (is_identifier(expression)) return expression.get_source();
        if (expression.get_kind() == ExpressionKind::BitSelect &&
            expression.get_operands().size() == 2) {
            const auto& base = expression.get_operands()[0];
            const auto& selector = expression.get_operands()[1];
            if (selector.get_kind() == ExpressionKind::Literal) {
                return expression.get_source();
            }
            const auto data_width = base.get_width();
            const auto selector_width = selector.get_width();
            if (!is_identifier(base) || !is_identifier(selector) ||
                data_width < 2 || selector_width == 0 ||
                selector_width >= sizeof(std::size_t) * 8 ||
                data_width != (std::size_t{1} << selector_width)) {
                return std::nullopt;
            }

            std::vector<std::string> values;
            values.reserve(data_width);
            for (std::size_t i = 0; i < data_width; ++i) {
                values.push_back(base.get_source() + "[" +
                                 std::to_string(i) + "]");
            }
            for (std::size_t level = 0; level < selector_width; ++level) {
                std::vector<std::string> next_values;
                next_values.reserve(values.size() / 2);
                for (std::size_t i = 0; i < values.size(); i += 2) {
                    const bool final_cell = values.size() == 2;
                    const auto output =
                        final_cell ? destination : unique_name("__generic_net");
                    if (!final_cell) nets.emplace_back(output, NetType::Internal);
                    add_cell(
                        "MUX2",
                        {{"A0", values[i]},
                         {"A1", values[i + 1]},
                         {"S", selector.get_source() + "[" +
                                   std::to_string(level) + "]"}},
                        output);
                    next_values.push_back(output);
                }
                values = std::move(next_values);
            }
            return destination;
        }
        if (const auto value = literal_value(expression)) {
            add_cell(*value ? "TIEHI" : "TIELO", {}, destination);
            return destination;
        }
        if (expression.get_kind() == ExpressionKind::Binary &&
            is_supported_operator(expression.get_value())) {
            std::vector<const Expression*> operands;
            if (!collect_associative(expression, expression.get_value(),
                                     operands)) {
                return std::nullopt;
            }
            if (operands.size() < 2) return std::nullopt;
            std::vector<PinConnection> connections;
            for (std::size_t i = 0; i < operands.size(); ++i) {
                const auto signal = lower(*operands[i], unique_name("__generic_net"));
                if (!signal) return std::nullopt;
                if (*signal != operands[i]->get_source() ||
                    !is_identifier(*operands[i])) {
                    nets.emplace_back(*signal, NetType::Internal);
                }
                connections.emplace_back(pin_name(i), *signal);
            }
            add_cell(generic_type_for_operator(expression.get_value(),
                                               operands.size()),
                     std::move(connections), destination);
            return destination;
        }
        if (expression.get_kind() == ExpressionKind::Unary &&
            (expression.get_value() == "~" || expression.get_value() == "!") &&
            expression.get_operands().size() == 1) {
            const auto& operand = expression.get_operands().front();
            const auto signal = lower(operand, unique_name("__generic_net"));
            if (!signal) return std::nullopt;
            if (!is_identifier(operand)) nets.emplace_back(*signal, NetType::Internal);
            add_cell("INV", {{"A", *signal}}, destination);
            return destination;
        }
        if (expression.get_kind() == ExpressionKind::Conditional &&
            expression.get_operands().size() == 3) {
            const auto& operands = expression.get_operands();
            std::vector<std::string> signals;
            for (const auto& operand : operands) {
                const auto signal = lower(operand, unique_name("__generic_net"));
                if (!signal) return std::nullopt;
                if (!is_identifier(operand)) nets.emplace_back(*signal, NetType::Internal);
                signals.push_back(*signal);
            }
            add_cell("MUX2",
                     {{"S", signals[0]}, {"A1", signals[1]},
                      {"A0", signals[2]}},
                     destination);
            return destination;
        }
        return std::nullopt;
    }
};

}  // namespace

Module generic_map(const Module& rtl_module) {
    const auto map_module =
        [&](const auto& self, const Module& source) -> Module {
        std::vector<Module> child_modules;
        child_modules.reserve(source.get_child_modules().size());
        for (const auto& child : source.get_child_modules()) {
            child_modules.push_back(self(self, child));
        }

        Module mapped;
        const bool requires_behavioral_lowering =
            source.is_behavioral() ||
            std::any_of(source.get_assignments().begin(),
                        source.get_assignments().end(),
                        [](const ContinuousAssignment& assignment) {
                            return !is_identifier(
                                assignment.get_lhs_expression());
                        });
        if (requires_behavioral_lowering) {
            mapped = detail::lower_behavioral_rtl(
                source.parsed_context_, source.get_name(), {}, true);
            mapped = Module(mapped.get_name(), mapped.get_ports(),
                            mapped.get_nets(), mapped.get_instances(),
                            mapped.get_assignments(), mapped.is_behavioral(),
                            source.get_hierarchy_instance_name(),
                            mapped.get_child_modules());
        } else {
            GenericMapper mapper(source);
            std::vector<ContinuousAssignment> remaining_assignments;

            for (const auto& assignment : source.get_assignments()) {
                const auto& lhs = assignment.get_lhs_expression();
                if (!is_identifier(lhs)) {
                    throw std::runtime_error(
                        "generic mapping currently requires scalar identifier assignment targets: " +
                        assignment.get_lhs());
                }
                const auto result =
                    mapper.lower(assignment.get_rhs_expression(), lhs.get_source());
                if (!result) {
                    throw std::runtime_error("continuous assignment '" +
                                             assignment.get_lhs() + " = " +
                                             assignment.get_rhs() +
                                             "' has no supported generic mapping");
                }
                if (*result != lhs.get_source()) {
                    mapper.add_cell("BUF", {{"A", *result}}, lhs.get_source());
                }
            }

            auto nets = source.get_nets();
            nets.insert(nets.end(),
                        std::make_move_iterator(mapper.nets.begin()),
                        std::make_move_iterator(mapper.nets.end()));
            auto instances = source.get_instances();
            for (std::size_t index = 0; index < instances.size();) {
                auto& instance = instances[index];
                const auto& cell_type = instance.get_cell_type();
                if (instance.is_user_defined_primitive()) {
                    mapper.lower_user_defined_primitive(instance, nets);
                    instances.erase(instances.begin() +
                                    static_cast<std::ptrdiff_t>(index));
                    continue;
                }
                if (is_switch_level_primitive(cell_type)) {
                    throw std::runtime_error(
                        "generic mapping does not support switch-level "
                        "primitive '" +
                        cell_type +
                        "'; use a synthesis flow with switch-level support");
                }
                const auto input_count = static_cast<std::size_t>(
                    std::count_if(
                        instance.get_connections().begin(),
                        instance.get_connections().end(),
                        [](const PinConnection& connection) {
                            return connection.get_pin() != "Y";
                        }));
                if (cell_type == "bufif0" || cell_type == "bufif1" ||
                    cell_type == "notif0" || cell_type == "notif1") {
                    if (input_count != 2) {
                        throw std::runtime_error(
                            "primitive gate '" + cell_type +
                            "' must have exactly two inputs");
                    }
                    const auto& connections = instance.get_connections();
                    const auto output = std::find_if(
                        connections.begin(), connections.end(),
                        [](const PinConnection& connection) {
                            return connection.get_pin() == "Y";
                        });
                    const auto data = std::find_if(
                        connections.begin(), connections.end(),
                        [](const PinConnection& connection) {
                            return connection.get_pin() == "A";
                        });
                    const auto enable = std::find_if(
                        connections.begin(), connections.end(),
                        [](const PinConnection& connection) {
                            return connection.get_pin() == "B";
                        });
                    if (output == connections.end() ||
                        data == connections.end() ||
                        enable == connections.end()) {
                        throw std::runtime_error(
                            "primitive gate '" + cell_type +
                            "' has invalid connections");
                    }

                    std::string data_net = data->get_net();
                    std::string enable_net = enable->get_net();
                    if (cell_type == "notif0" || cell_type == "notif1") {
                        const auto inverted =
                            mapper.unique_name("__generic_net");
                        nets.emplace_back(inverted, NetType::Internal);
                        mapper.add_cell("INV", {{"A", data_net}}, inverted);
                        data_net = inverted;
                    }
                    if (cell_type == "bufif1" || cell_type == "notif1") {
                        const auto inverted =
                            mapper.unique_name("__generic_net");
                        nets.emplace_back(inverted, NetType::Internal);
                        mapper.add_cell("INV", {{"A", enable_net}}, inverted);
                        enable_net = inverted;
                    }
                    instance = Instance(
                        instance.get_name(), "TRIBUF",
                        {{"A", std::move(data_net)},
                         {"TE_B", std::move(enable_net)},
                         {"Y", output->get_net()}});
                    continue;
                }
                const auto generic_type = generic_type_for_primitive(
                    cell_type, input_count);
                if (generic_type) {
                    instance = Instance(instance.get_name(),
                                        *generic_type,
                                        instance.get_connections());
                }
                ++index;
            }
            instances.insert(
                instances.end(),
                std::make_move_iterator(mapper.instances.begin()),
                std::make_move_iterator(mapper.instances.end()));
            mapped = Module(source.get_name(), source.get_ports(),
                            std::move(nets), std::move(instances),
                            std::move(remaining_assignments),
                            source.is_behavioral(),
                            source.get_hierarchy_instance_name(),
                            std::move(child_modules));
        }

        return mapped;
    };

    return map_module(map_module, rtl_module);
}

Module generic_map(const Project& project, const std::string& top,
                   const std::map<std::string, std::string>& parameters) {
    std::unordered_map<std::string, const Module*> by_name;
    std::unordered_set<std::string> instantiated;
    for (const auto& module : project.get_modules()) by_name[module.get_name()] = &module;
    for (const auto& module : project.get_modules()) {
        for (const auto& instance : module.get_instances()) {
            if (by_name.count(instance.get_cell_type())) {
                instantiated.insert(instance.get_cell_type());
            }
        }
    }

    std::string top_name = top;
    if (top_name.empty()) {
        for (const auto& module : project.get_modules()) {
            if (instantiated.count(module.get_name())) continue;
            if (!top_name.empty()) {
                throw std::runtime_error(
                    "project has several top-level modules; pass top=<module>");
            }
            top_name = module.get_name();
        }
        if (top_name.empty()) throw std::runtime_error("project has no top-level module");
    }
    const auto top_module = by_name.find(top_name);
    if (top_module == by_name.end()) {
        throw std::runtime_error("top module '" + top_name + "' not found in project");
    }

    if (parameters.empty()) {
        std::unordered_set<std::string> active_modules;
        const auto build_hierarchy =
            [&](const auto& self, const Module& source,
                const std::string& instance_name) -> Module {
            if (!active_modules.insert(source.get_name()).second) {
                throw std::runtime_error(
                    "recursive module hierarchy detected at '" +
                    source.get_name() + "'");
            }

            std::vector<Module> children;
            for (const auto& instance : source.get_instances()) {
                const auto child = by_name.find(instance.get_cell_type());
                if (child != by_name.end()) {
                    children.push_back(
                        self(self, *child->second, instance.get_name()));
                }
            }

            active_modules.erase(source.get_name());
            Module hierarchy_node(
                source.get_name(), source.get_ports(), source.get_nets(),
                source.get_instances(), source.get_assignments(),
                source.is_behavioral(), instance_name, std::move(children));
            hierarchy_node.parsed_context_ = source.parsed_context_;
            return hierarchy_node;
        };
        auto hierarchy =
            build_hierarchy(build_hierarchy, *top_module->second, {});
        hierarchy.parsed_context_ = project.parsed_context_;
        return generic_map(hierarchy);
    }

    // Parameter overrides use project-wide elaboration so the specialized
    // design reflects the selected top-level values.
    bool needs_lowering = !parameters.empty();
    std::vector<const Module*> pending{top_module->second};
    std::unordered_set<std::string> visited;
    while (!pending.empty()) {
        const Module* module = pending.back();
        pending.pop_back();
        if (!visited.insert(module->get_name()).second) continue;
        if (module->is_behavioral()) needs_lowering = true;
        for (const auto& instance : module->get_instances()) {
            const auto child = by_name.find(instance.get_cell_type());
            if (child == by_name.end()) continue;
            needs_lowering = true;
            pending.push_back(child->second);
        }
    }
    if (!needs_lowering) return generic_map(*top_module->second);
    return detail::lower_behavioral_rtl(project.parsed_context_, top_name,
                                        parameters, true);
}

}  // namespace labneura::eda
